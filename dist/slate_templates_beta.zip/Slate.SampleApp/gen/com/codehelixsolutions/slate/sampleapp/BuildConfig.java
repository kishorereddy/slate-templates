/** Automatically generated file. DO NOT MODIFY */
package com.codehelixsolutions.slate.sampleapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}