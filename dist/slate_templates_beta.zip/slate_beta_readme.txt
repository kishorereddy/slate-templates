ABOUT
Slate is a templating engine for building native mobile user interfaces.


SITE
Company site: http://www.slatetemplates.com
Github  docs: https://github.com/kishorereddy/slate-templates


SAMPLE APP
Provided here is a sample android using slate tempaltes on the main activity screen.
It loads some text, variables and images dynamically using the templates.
The slate templates jar file is in the libs forlder slate.templates.jar.



BETA
This is a beta version with potential bugs. 
Please refer to notes and documentation on our site links above.


LICENSE
1. Slate templates is free for personal use.
2. The beta version is also free for personal use.
3. We plan on having a production version ready in a few weeks. 
4. The production version requires a license for commercial use in paid apps and apps with in-app purchases.
5. A license is also required if you are using slate templates in the enterprise.

Please refer to license info on our site links above.


CONTACT US
Please contact us at the site links listed above for more information.


COMPANY
CodeHelix Solutions Inc
http://www.codehelixsolutions.com

